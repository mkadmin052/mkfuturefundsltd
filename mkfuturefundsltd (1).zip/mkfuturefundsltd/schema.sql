-- ═══════════════════════════════════════════════
-- MK FUTURE FUNDS — SUPABASE SCHEMA
-- Run this in Supabase SQL Editor (Project → SQL Editor → New Query)
-- ═══════════════════════════════════════════════

-- Enable UUID generation
create extension if not exists "pgcrypto";

-- ─────────────────────────────────────
-- PROFILES (mirrors auth.users, holds app data)
-- ─────────────────────────────────────
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,              -- phone number
  first_name text not null,
  last_name text not null,
  role text not null default 'user',           -- 'user' | 'admin'
  account_type text not null default 'INTERN', -- INTERN, VIP1..VIP5
  registration_date date not null default current_date,
  vip_start_date date,
  total_balance numeric(14,2) not null default 0,
  invest_balance numeric(14,2) not null default 0,
  task_balance numeric(14,2) not null default 0,
  withdrawable numeric(14,2) not null default 0,
  must_set_password boolean not null default false,
  force_password_reset boolean not null default false,
  last_seen bigint default 0,
  is_full_time boolean default false,
  status text default 'active',
  withdrawal_bank_account text,
  bank_account_id uuid,
  created_at timestamptz not null default now()
);

-- ─────────────────────────────────────
-- INVESTMENT PRODUCTS (admin-created offerings)
-- ─────────────────────────────────────
create table investment_products (
  id uuid primary key default gen_random_uuid(),
  name text,
  rate numeric(8,4),
  duration_days integer,
  start_date date,
  end_date date,
  created_at timestamptz not null default now()
);

-- ─────────────────────────────────────
-- INVESTMENT PURCHASES (user buy-ins)
-- ─────────────────────────────────────
create table investment_purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  username text,
  product_id uuid references investment_products(id) on delete set null,
  product_name text,
  rate numeric(8,4),
  duration_days integer,
  duration integer,  -- kept in sync with duration_days for legacy dashboard code paths
  amount numeric(14,2),
  expected_payout numeric(14,2),
  purchase_date date,
  maturity_date date,
  status text default 'Active',
  created_at timestamptz not null default now()
);

-- ─────────────────────────────────────
-- PENDING REGISTRATIONS (before admin approval, before Auth account exists)
-- ─────────────────────────────────────
create table pending_registrations (
  id uuid primary key default gen_random_uuid(),
  phone text not null,
  firstname text not null,
  lastname text not null,
  password text not null,        -- temporary plaintext holding; deleted once approved & Auth account created
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

-- ─────────────────────────────────────
-- TASKS
-- ─────────────────────────────────────
create table tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  username text,
  date date default current_date,
  task text,
  reward numeric(14,2),
  status text default 'Pending',
  created_at timestamptz not null default now()
);

-- ─────────────────────────────────────
-- TRANSACTIONS
-- ─────────────────────────────────────
create table transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  username text,
  type text,                     -- Deposit, Withdraw
  amount numeric(14,2),
  status text default 'Pending',
  proof_path text,
  date date default current_date,
  created_at timestamptz not null default now()
);

-- ─────────────────────────────────────
-- ADMIN ACTIVITY LOG
-- ─────────────────────────────────────
create table admin_activities (
  id uuid primary key default gen_random_uuid(),
  admin_username text,
  action text,
  details text,
  created_at timestamptz not null default now()
);

-- ─────────────────────────────────────
-- BANK ACCOUNTS (admin-managed list of company receiving accounts)
-- ─────────────────────────────────────
create table bank_accounts (
  id uuid primary key default gen_random_uuid(),
  bank_name text,
  account_holder text,
  account_number text,
  active boolean default true,
  created_at timestamptz not null default now()
);

alter table profiles add constraint profiles_bank_account_fk
  foreign key (bank_account_id) references bank_accounts(id) on delete set null;

-- ─────────────────────────────────────
-- BANK CHANGE REQUESTS
-- ─────────────────────────────────────
create table bank_change_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  user_phone text,
  current_bank_id uuid references bank_accounts(id) on delete set null,
  new_bank_id uuid references bank_accounts(id) on delete set null,
  status text default 'pending',
  approved_at timestamptz,
  declined_at timestamptz,
  created_at timestamptz not null default now()
);

-- ─────────────────────────────────────
-- SA HOLIDAYS
-- ─────────────────────────────────────
create table sa_holidays (
  id uuid primary key default gen_random_uuid(),
  date date not null,
  name text not null,
  is_custom boolean default false
);

-- ─────────────────────────────────────
-- VIP RATES (single-row config table, admin-editable)
-- ─────────────────────────────────────
create table vip_rates (
  tier text primary key,          -- INTERN, VIP1, VIP2, VIP3, VIP4, VIP5
  daily_rate numeric(6,4) not null default 0
);

insert into vip_rates (tier, daily_rate) values
  ('INTERN', 0), ('VIP1', 0), ('VIP2', 0), ('VIP3', 0), ('VIP4', 0), ('VIP5', 0);

-- ─────────────────────────────────────
-- ADMIN MESSAGE (single row banner)
-- ─────────────────────────────────────
create table admin_message (
  id int primary key default 1,
  message text default '',
  constraint single_row check (id = 1)
);
insert into admin_message (id, message) values (1, '');

-- ─────────────────────────────────────
-- ADMIN PASSWORD RESET REQUESTS
-- ─────────────────────────────────────
create table admin_password_reset_requests (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references profiles(id) on delete cascade,
  username text,
  name text,
  status text default 'Pending',
  requested_at timestamptz not null default now()
);

-- ─────────────────────────────────────
-- PAYOUT LOGS (daily VIP income payout history)
-- ─────────────────────────────────────
create table payout_logs (
  id uuid primary key default gen_random_uuid(),
  username text,
  date date,
  amount numeric(14,2),
  status text default 'Completed',
  auto boolean default false,
  created_at timestamptz not null default now()
);

-- ─────────────────────────────────────
-- PRIVATE MESSAGES (admin <-> user chat)
-- ─────────────────────────────────────
create table private_messages (
  id uuid primary key default gen_random_uuid(),
  "from" text,
  "to" text,
  message text,
  read boolean default false,
  created_at timestamptz not null default now()
);

-- ═══════════════════════════════════════════════
-- ROW LEVEL SECURITY
-- ═══════════════════════════════════════════════

alter table profiles enable row level security;
alter table pending_registrations enable row level security;
alter table tasks enable row level security;
alter table transactions enable row level security;
alter table admin_activities enable row level security;
alter table bank_change_requests enable row level security;
alter table bank_accounts enable row level security;
alter table sa_holidays enable row level security;
alter table vip_rates enable row level security;
alter table admin_message enable row level security;
alter table investment_products enable row level security;
alter table investment_purchases enable row level security;
alter table payout_logs enable row level security;
alter table private_messages enable row level security;

alter table admin_password_reset_requests enable row level security;

-- Helper: is the current user an admin or master_admin?
create or replace function is_admin() returns boolean as $$
  select exists (
    select 1 from profiles where id = auth.uid() and role in ('admin', 'master_admin')
  );
$$ language sql security definer stable;

-- PROFILES: users see/edit their own row; admins see/edit all
create policy "profiles_select_own_or_admin" on profiles
  for select using (auth.uid() = id or is_admin());
create policy "profiles_update_own_or_admin" on profiles
  for update using (auth.uid() = id or is_admin());
create policy "profiles_insert_admin" on profiles
  for insert with check (is_admin());

-- PENDING REGISTRATIONS: anyone can insert (signup); only admin can read/update/delete
create policy "pending_insert_anyone" on pending_registrations
  for insert with check (true);
create policy "pending_select_admin" on pending_registrations
  for select using (is_admin());
create policy "pending_delete_admin" on pending_registrations
  for delete using (is_admin());
-- Allow the person who just registered to poll their own row's existence via a public read
-- (safe because it only exposes the row while status='pending' and id is a random UUID they already hold)
create policy "pending_select_own_by_id" on pending_registrations
  for select using (true);

-- TASKS: user sees own; admin sees all
create policy "tasks_select_own_or_admin" on tasks
  for select using (auth.uid() = user_id or is_admin());
create policy "tasks_insert_own_or_admin" on tasks
  for insert with check (auth.uid() = user_id or is_admin());
create policy "tasks_update_admin" on tasks
  for update using (is_admin());

-- TRANSACTIONS: user sees own; admin sees all
create policy "txn_select_own_or_admin" on transactions
  for select using (auth.uid() = user_id or is_admin());
create policy "txn_insert_own_or_admin" on transactions
  for insert with check (auth.uid() = user_id or is_admin());
create policy "txn_update_admin" on transactions
  for update using (is_admin());

-- ADMIN ACTIVITIES: admin only
create policy "activities_all_admin" on admin_activities
  for all using (is_admin()) with check (is_admin());

-- BANK CHANGE REQUESTS: user manages own; admin manages all
create policy "bank_select_own_or_admin" on bank_change_requests
  for select using (auth.uid() = user_id or is_admin());
create policy "bank_insert_own" on bank_change_requests
  for insert with check (auth.uid() = user_id);
create policy "bank_update_admin" on bank_change_requests
  for update using (is_admin());

-- BANK ACCOUNTS: everyone can read active accounts (for withdrawal setup); admin writes
create policy "bankacct_select_all" on bank_accounts
  for select using (true);
create policy "bankacct_write_admin" on bank_accounts
  for all using (is_admin()) with check (is_admin());

-- SA HOLIDAYS: everyone can read; admin can write
create policy "holidays_select_all" on sa_holidays
  for select using (true);
create policy "holidays_write_admin" on sa_holidays
  for all using (is_admin()) with check (is_admin());

-- VIP RATES: everyone can read; admin can write
create policy "rates_select_all" on vip_rates
  for select using (true);
create policy "rates_write_admin" on vip_rates
  for all using (is_admin()) with check (is_admin());

-- ADMIN PASSWORD RESET REQUESTS: any authenticated context can insert (forgot-password flow is pre-login,
-- so we allow anon insert here); only admin/master_admin can read/update
create policy "reset_req_insert_anyone" on admin_password_reset_requests
  for insert with check (true);
create policy "reset_req_select_admin" on admin_password_reset_requests
  for select using (is_admin());
create policy "reset_req_update_admin" on admin_password_reset_requests
  for update using (is_admin());

-- Allow unauthenticated lookup of an admin's existence by username for the
-- "forgot password" flow (returns only id/username/role, no secrets)
create policy "profiles_select_admin_lookup" on profiles
  for select using (role in ('admin', 'master_admin'));

-- ADMIN MESSAGE: everyone can read; admin can write
create policy "msg_select_all" on admin_message
  for select using (true);
create policy "msg_write_admin" on admin_message
  for all using (is_admin()) with check (is_admin());

-- INVESTMENT PRODUCTS: everyone can read; admin writes
create policy "invprod_select_all" on investment_products
  for select using (true);
create policy "invprod_write_admin" on investment_products
  for all using (is_admin()) with check (is_admin());

-- INVESTMENT PURCHASES: user sees/creates own; admin sees/manages all
create policy "invpurch_select_own_or_admin" on investment_purchases
  for select using (auth.uid() = user_id or is_admin());
create policy "invpurch_insert_own" on investment_purchases
  for insert with check (auth.uid() = user_id);
create policy "invpurch_update_own_or_admin" on investment_purchases
  for update using (auth.uid() = user_id or is_admin());

-- PAYOUT LOGS: admin sees/writes all; users see only their own
create policy "payout_select_own_or_admin" on payout_logs
  for select using (is_admin() or username = (select username from profiles where id = auth.uid()));
create policy "payout_write_admin" on payout_logs
  for insert with check (is_admin());

-- PRIVATE MESSAGES: participants (by username) can read/send; admin can read all
create policy "msgs_select_participant_or_admin" on private_messages
  for select using (
    is_admin()
    or "from" = (select username from profiles where id = auth.uid())
    or "to"   = (select username from profiles where id = auth.uid())
  );
create policy "msgs_insert_as_self" on private_messages
  for insert with check (
    "from" = (select username from profiles where id = auth.uid())
  );

-- ═══════════════════════════════════════════════
-- ONE-TIME: BOOTSTRAP YOUR FIRST MASTER ADMIN
-- ═══════════════════════════════════════════════
-- The app has no way to create the very first master_admin (chicken-and-egg:
-- creating one normally requires being logged in as one). Do this once:
--
-- 1. In Supabase Dashboard → Authentication → Users → "Add user":
--      Email:    madmin@mkfuturefunds.local   (or your chosen master admin phone + @mkfuturefunds.local)
--      Password: <choose a strong password>
--      Auto Confirm User: YES
--
-- 2. Copy the new user's UUID from that screen, then run this (replace the UUID and username):
--
--   insert into profiles (id, username, first_name, last_name, role, account_type)
--   values ('PASTE-USER-UUID-HERE', 'madmin', 'Master', 'Admin', 'master_admin', 'INTERN');
--
-- 3. Log in through the "Master Admin" tab in the app using the phone/username you chose
--    (e.g. "madmin") and the password you set in step 1.

