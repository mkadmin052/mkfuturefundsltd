// Supabase Edge Function: approve-registration
// Handles three admin-only actions that require the service_role key:
//   action: 'approve'        — approve a pending registration (default if omitted)
//   action: 'create-user'    — admin directly creates a new user
//   action: 'reset-password' — admin resets an existing user's password
// Deploy with: supabase functions deploy approve-registration
// This runs server-side with the service_role key — never expose that key to the browser.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

Deno.serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  }

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const body = await req.json()
    const action = body.action || 'approve'

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

    const authHeader = req.headers.get('Authorization')!
    const callerClient = createClient(supabaseUrl, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    })
    const { data: { user: caller } } = await callerClient.auth.getUser()
    if (!caller) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), { status: 401, headers: corsHeaders })
    }

    const { data: callerProfile } = await callerClient
      .from('profiles')
      .select('role')
      .eq('id', caller.id)
      .single()

    if (!callerProfile || !['admin', 'master_admin'].includes(callerProfile.role)) {
      return new Response(JSON.stringify({ error: 'Not authorized — admin only' }), { status: 403, headers: corsHeaders })
    }

    const adminClient = createClient(supabaseUrl, serviceRoleKey)

    // ─────────────────────────────────────
    if (action === 'approve') {
      const { registrationId, adminUsername } = body
      const { data: reg, error: regErr } = await adminClient
        .from('pending_registrations')
        .select('*')
        .eq('id', registrationId)
        .single()

      if (regErr || !reg) {
        return new Response(JSON.stringify({ error: 'Registration not found' }), { status: 404, headers: corsHeaders })
      }

      const syntheticEmail = `${reg.phone}@mkfuturefunds.local`
      const { data: newUser, error: createErr } = await adminClient.auth.admin.createUser({
        email: syntheticEmail,
        password: reg.password,
        email_confirm: true,
      })

      if (createErr || !newUser.user) {
        return new Response(JSON.stringify({ error: createErr?.message || 'Failed to create user' }), { status: 500, headers: corsHeaders })
      }

      const { error: profileErr } = await adminClient.from('profiles').insert({
        id: newUser.user.id,
        username: reg.phone,
        first_name: reg.firstname,
        last_name: reg.lastname,
        role: 'user',
        account_type: 'INTERN',
        total_balance: 0, invest_balance: 0, task_balance: 0, withdrawable: 0,
      })

      if (profileErr) {
        await adminClient.auth.admin.deleteUser(newUser.user.id)
        return new Response(JSON.stringify({ error: profileErr.message }), { status: 500, headers: corsHeaders })
      }

      await adminClient.from('pending_registrations').delete().eq('id', registrationId)
      await adminClient.from('admin_activities').insert({
        admin_username: adminUsername || caller.email,
        action: 'Approved User Registration',
        details: `Phone: ${reg.phone}, Name: ${reg.firstname} ${reg.lastname}`,
      })

      return new Response(JSON.stringify({ success: true, userId: newUser.user.id }), {
        status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // ─────────────────────────────────────
    if (action === 'create-user') {
      const { username, password, profileFields } = body
      const syntheticEmail = `${username}@mkfuturefunds.local`

      const { data: newUser, error: createErr } = await adminClient.auth.admin.createUser({
        email: syntheticEmail,
        password,
        email_confirm: true,
      })
      if (createErr || !newUser.user) {
        return new Response(JSON.stringify({ error: createErr?.message || 'Failed to create user' }), { status: 500, headers: corsHeaders })
      }

      const { error: profileErr } = await adminClient.from('profiles').insert({
        id: newUser.user.id,
        username,
        ...profileFields,
      })
      if (profileErr) {
        await adminClient.auth.admin.deleteUser(newUser.user.id)
        return new Response(JSON.stringify({ error: profileErr.message }), { status: 500, headers: corsHeaders })
      }

      return new Response(JSON.stringify({ success: true, userId: newUser.user.id }), {
        status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // ─────────────────────────────────────
    if (action === 'reset-password') {
      const { userId, newPassword } = body
      const { error: resetErr } = await adminClient.auth.admin.updateUserById(userId, { password: newPassword })
      if (resetErr) {
        return new Response(JSON.stringify({ error: resetErr.message }), { status: 500, headers: corsHeaders })
      }
      return new Response(JSON.stringify({ success: true }), {
        status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // ─────────────────────────────────────
    if (action === 'delete-user') {
      const { userId } = body
      await adminClient.from('profiles').delete().eq('id', userId)
      const { error: delErr } = await adminClient.auth.admin.deleteUser(userId)
      if (delErr) {
        return new Response(JSON.stringify({ error: delErr.message }), { status: 500, headers: corsHeaders })
      }
      return new Response(JSON.stringify({ success: true }), {
        status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    return new Response(JSON.stringify({ error: 'Unknown action' }), { status: 400, headers: corsHeaders })
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders })
  }
})
